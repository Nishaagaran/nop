package Utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
public class browsers {

	
	WebDriver driver;
	Properties prop;
	
	public WebDriver browser_intiate() throws IOException
	{
			
	FileInputStream fis=new FileInputStream("D:\\selenium_q&A\\NopCommerce_\\Resources\\config.properties");
	prop=new Properties();
	prop.load(fis);
	String br_name=prop.getProperty("browser");
	switch(br_name)
	{
	case "chrome":
	{
		ChromeOptions opt=new ChromeOptions();
		opt.addArguments("Start-Maximised");
	WebDriverManager.chromedriver().setup();
driver=new ChromeDriver(opt);
	break;
	}
	case "edge":
	{	
driver=new EdgeDriver();
break;
}
	}
	return driver;
}
	
	public void url()
	{
		driver.get(prop.getProperty("url"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	}
}

	