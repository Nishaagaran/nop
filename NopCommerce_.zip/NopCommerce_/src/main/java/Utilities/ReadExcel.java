package Utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {

	public String[] readingdata() throws IOException {
		FileInputStream fis=new FileInputStream("");
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheetAt(0);
		Row r=sh.getRow(0);
		String user=r.getCell(0).getStringCellValue();
		String pass=r.getCell(1).getStringCellValue();
		String data[] = {user,pass};
		return data;
		
	}
}
