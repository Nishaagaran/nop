package PageObjREpo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class login {

WebDriver driver;	
	public login(WebDriver driver)
	{
		this.driver=driver;
	}
	//By user=By.id(null)
	@FindBy(id="Username")
	WebElement user;
	
	@FindBy(id="Password")
	WebElement pass;
	
	@FindBy(xpath="//input[@value='Log in']")
	WebElement login;
	
	
	public void login(String username, String password) {
		// TODO Auto-generated method stub
		user.sendKeys(username);
		pass.sendKeys(password);
		login.click();
	}
}
