package nopcommerce.NopCommerce_;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import PageObjREpo.login;
import Utilities.ReadExcel;
import Utilities.browsers;

public class AppTest
{
	WebDriver driver;
	@Test
	public void test1() throws IOException
	{
		browsers br=new browsers();
		driver=br.browser_intiate();
		br.url();
	//	login l=new login(driver);
		login l= PageFactory.initElements(driver,login.class);
		ReadExcel r=new ReadExcel();
	String ar[]=r.readingdata();
	String data=ar[0];
	String data1=ar[1];
		l.login(data,data1);
	}
	
		
	}